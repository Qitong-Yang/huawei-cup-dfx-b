# Localization: stack_top_20261020_155228_322941_f85f4652

| 指标 | 命中 | 分母 | 比例 |
|---|---|---|---|
| exact | 18 | 25 | 72.0% |
| range | 21 | 25 | 84.0% |
| function | 22 | 25 | 88.0% |
| file | 24 | 25 | 96.0% |
| top3_exact | 18 | 25 | 72.0% |

排除案例（不计入分母）：2
- `TC_JSError_002@ComprehensiveNews1@B2`：fault not present in shipped source: HistoryVM.toDeleteList is never null and the logged line 48 is '} else {'. The log in this case's own folder belongs to TC_JSError_003.
- `TC_JSError_018@ImageProcessing1@B3`：no crash log: the archive contains MainEntry.ets instead of a jscrash log.

执行覆盖（不从主指标分母中删除阻塞／错误案例）：
- scorable_total: 25
- executed: 25
- candidate: 25
- unresolved: 0
- blocked: 0
- error: 0

| 案例 | 预测 | exact | range | function | file |
|---|---|---|---|---|---|
| TC_JSError_002@AccountingApp1@B1 | `components/bill_chart/src/main/ets/components/BillBarChart.ets:228` | ✓ | ✓ | ✓ | ✓ |
| TC_JSError_004@BookRead2@B1 | `feature/book_home/src/main/ets/views/BookViewListPage.ets:21` | ✓ | ✓ | ✓ | ✓ |
| TC_JSError_007@Calendar1@B1 | `components/date_calculation/src/main/ets/utils/Utils.ets:55` | ✓ | ✓ | ✓ | ✓ |
| TC_JSError_001@ComprehensiveTool1@B1 | `components/money_track/src/main/ets/viewmodels/ResourceManageVM.ets:83` | ✗ | ✗ | ✓ | ✓ |
| TC_JSError_009@EnterpriseRecruitment2@B1 | `commons/component/src/main/ets/utils/PropUtil.js:3` | ✓ | ✓ | ✓ | ✓ |
| TC_JSError_010@Express1@B1 | `features/business_home/src/main/ets/viewModels/ExpressPageVM.ets:354` | ✓ | ✓ | ✓ | ✓ |
| TC_JSError_005@MoneyTrack1_2@B1 | `features/assets/src/main/ets/viewmodels/AssetAnalysisVM.ets:110` | ✗ | ✓ | ✓ | ✓ |
| TC_JSError_025@Music1@B1 | `components/module_musicplay/src/main/ets/components/PlayerControlArea.ets:190` | ✓ | ✓ | ✓ | ✓ |
| TC_JSError_006@Notes1@B1 | `common/datasource/src/main/ets/NoteService.ets:287` | ✗ | ✗ | ✗ | ✓ |
| TC_JSError_026@Teleprompter1@B1 | `components/teleprompter/src/main/ets/components/ConfigSheet.ets:232` | ✓ | ✓ | ✓ | ✓ |
| TC_JSError_011@ChildrenEducation1@B2 | `commons/utils/src/main/ets/player/VideoPlayPage.ets:72` | ✓ | ✓ | ✓ | ✓ |
| TC_JSError_001@ComprehensiveMall1@B2 | `features/order/src/main/ets/views/OrderInfoPage.ets:119` | ✓ | ✓ | ✓ | ✓ |
| TC_JSError_003@ComprehensiveNews1@B2 | `commons/lib_news_feed_details/src/main/ets/views/ArticleFeedDetails.ets:111` | ✗ | ✓ | ✗ | ✓ |
| TC_JSError_005@MoneyTrack1@B2 | `features/statistics/src/main/ets/components/CalendarSummary.ets:55` | ✓ | ✓ | ✓ | ✓ |
| TC_JSRangeError_024@WebShortDrama1@B2 | `components/aggregated_share/src/main/ets/views/ShareView.ets:40` | ✓ | ✓ | ✓ | ✓ |
| TC_JSError_012@HomeStay1.0.6@B3 | `components/travel_discovery/src/main/ets/model/Index.ets:65` | ✗ | ✗ | ✗ | ✗ |
| TC_JSError_014@DriverLicenseExam1.0.7@B3 | `commons/datasource/src/main/ets/ExamService.ets:345` | ✓ | ✓ | ✓ | ✓ |
| TC_JSError_015@FitnessCenter1.0.3@B3 | `components/search/src/main/ets/views/ResultPage.ets:163` | ✓ | ✓ | ✓ | ✓ |
| TC_JSError_016@TouristAttraction1@B3 | `components/module_base/src/main/ets/util/CommonUtil.ets:10` | ✓ | ✓ | ✓ | ✓ |
| TC_JSError_017@OfficeAttendance1@B3 | `scenes/agency/src/main/ets/mock/DataManager.ets:56` | ✓ | ✓ | ✓ | ✓ |
| TC_JSError_019@Exam1@B3 | `components/select_category/src/main/ets/components/MainPage.ets:65` | ✗ | ✓ | ✓ | ✓ |
| TC_JSError_020@TeaDrinkOrders1@B3 | `features/order/src/main/ets/pages/ConfirmOrderPage.ets:786` | ✓ | ✓ | ✓ | ✓ |
| TC_JSError_021@AudioEditing1@B3 | `components/audio_common/src/main/ets/viewModel/EditViewModel.ets:58` | ✗ | ✗ | ✓ | ✓ |
| TC_JSError_022@HouseholdService1@B3 | `commons/lib_foundation/src/main/ets/http/OrderRequestChecksum.ets:23` | ✓ | ✓ | ✓ | ✓ |
| TC_JSError_024@WebShortDrama1@B3 | `components/feedback/src/main/ets/utils/FileUtils.ets:173` | ✓ | ✓ | ✓ | ✓ |
