// 属性存在性检查
export function hasKey(obj, key) {
  return key in obj;
}
