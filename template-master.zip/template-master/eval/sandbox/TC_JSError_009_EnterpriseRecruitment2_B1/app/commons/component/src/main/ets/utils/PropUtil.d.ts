export declare function hasKey(obj: object | undefined, key: string): boolean;
