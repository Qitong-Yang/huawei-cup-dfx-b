export class DramaListReq{

}